<template lang="html">
  <div>人家是有底线的 -.-</div>

</template>

<script>
  export default {}
</script>

<style lang="less" scoped>
  div {
    padding: 8vw 0;
    text-align: center;
    letter-spacing: .2vw;
    color: rgb(158, 158, 158);
    font-family: Lato, "Microsoft Jhenghei", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
    font-weight: 600;
    font-size: 14px;
  }
</style>
