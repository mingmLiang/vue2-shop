<template lang="html">
  <div class="">
    未完待续

  </div>
</template>

<script>
export default {
}
</script>

<style lang="less" scoped>
@import '../assets/fz.less';

</style>
